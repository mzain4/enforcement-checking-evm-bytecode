contract Pragma{
    uint pragma;
}