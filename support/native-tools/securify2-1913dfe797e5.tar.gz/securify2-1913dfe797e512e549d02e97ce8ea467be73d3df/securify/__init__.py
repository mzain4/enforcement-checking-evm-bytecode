class SecurifyError(Exception):
    pass
